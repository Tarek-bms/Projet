(function(){
  var $mainWrapper = $("#main-wrapper");

  $('.menu-icon').click(function(){
      $(this).toggleClass('active');
      $mainWrapper.toggleClass('active');
  });


})();